function R = MTHolm(y, X, sigma, alpha, k, modified, cov, knsig)
%% Returns indices of coefficients rejected by Holm's procedure applied to
% the OLS p-values of y regressed on X.

if nargin < 8, knsig = true; end
if nargin < 7, XtX = X'*X; cov = inv(XtX); end
if nargin < 6, modified = true; end
n = size(X,1);

ols = cov*(X'*y);
z = ols ./ (sigma*sqrt(diag(cov)));
if knsig
    p = 2 - 2*normcdf(abs(z));
else
    sigmahat = sqrt(sum((y-X*ols).^2)/(n-size(X,2)));
    p = 2 - 2*tcdf(abs(z*sigma/sigmahat),n-size(X,2));
end
[p_ord, ind] = sort(p);
thresh = find(cumprod(p_ord <= k*alpha./((length(p):-1:1)+k-1)'), 1, 'last');
if modified, thresh = max([thresh (k-1)]); end
R = ind(1:thresh)';
end