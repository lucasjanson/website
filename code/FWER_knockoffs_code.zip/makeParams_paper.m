%%
m = 400;
nobs = 1000;
pfrac = 450/1000;
sig2 = 5^2;
alpha = .05;
k = 5;
modified = 1;
nsim = 10000;
version = 7;
repeats = 5;

p.m = [m]';
p.n = [nobs]';
p.pfrac = [pfrac]';
p.sig2 = [sig2]';
p.alpha = [alpha]';
p.k = [k]';
p.modified = [modified]';
p.mag = [10]';
p.false_inds_frac = [.1*2/9]';
p.nsim = [nsim]';
p.rho = (0:0.1:0.5)';
p.version = version; % change this for new experiments
version_num = p.version;
repeats = repeats;

p = struct2cell(p);

len = nan(length(p), 1);
for i = 1:length(p), len(i) = length(p{i}); end
n = prod(len);

for i = 1:(length(p)-1)
    for j = 1:i
		p{j} = repmat(p{j}, len(i+1), 1);
    end
    for j = (i+1):length(p)
		p{j} = vec(repmat(p{j}', len(i), 1));
    end
end
params = cell2mat(p');
any(any(isnan(params)))

params = reshape(repmat(params,1,repeats)', size(params,2),size(params,1)*repeats)';
params2 = params;

p.m = [m]';
p.n = [nobs]';
p.pfrac = [pfrac]';
p.sig2 = [sig2]';
p.alpha = [alpha]';
p.k = [k]';
p.modified = [modified]';
p.mag = [.1 .3 1 3 10 30 100]';
p.false_inds_frac = [.1*2/9]';
p.nsim = [nsim]';
p.rho = (0)';
p.version = version; % change this for new experiments
version_num = p.version;
repeats = repeats;

p = struct2cell(p);

len = nan(length(p), 1);
for i = 1:length(p), len(i) = length(p{i}); end
n = prod(len);

for i = 1:(length(p)-1)
    for j = 1:i
		p{j} = repmat(p{j}, len(i+1), 1);
    end
    for j = (i+1):length(p)
		p{j} = vec(repmat(p{j}', len(i), 1));
    end
end
params = cell2mat(p');
any(any(isnan(params)))

params = reshape(repmat(params,1,repeats)', size(params,2),size(params,1)*repeats)';
params2 = [params2; params];

p.m = [m]';
p.n = [nobs]';
p.pfrac = [pfrac]';
p.sig2 = [sig2]';
p.alpha = [alpha]';
p.k = [k]';
p.modified = [modified]';
p.mag = [10]';
p.false_inds_frac = [.1/45 .1/9 .1*2/9 .1*4/9 .1*6/9 .1*8/9 .1*11/9]';
p.nsim = [nsim]';
p.rho = (0)';
p.version = version; % change this for new experiments
version_num = p.version;
repeats = repeats;

p = struct2cell(p);

len = nan(length(p), 1);
for i = 1:length(p), len(i) = length(p{i}); end
n = prod(len);

for i = 1:(length(p)-1)
    for j = 1:i
		p{j} = repmat(p{j}, len(i+1), 1);
    end
    for j = (i+1):length(p)
		p{j} = vec(repmat(p{j}', len(i), 1));
    end
end
params = cell2mat(p');
any(any(isnan(params)))

params = reshape(repmat(params,1,repeats)', size(params,2),size(params,1)*repeats)';
params = [params2; params];

save(['paramsFWER' num2str(version_num) '.mat'], 'params')
