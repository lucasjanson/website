fwer_exper3.m:
  Runs simulations comparing knockoffs to competitor k-FWER-controlling procedures

knockoffCreate.m:
  Generates knockoff matrix from a given design matrix

kthvalue.m:
  Computes the k'th smallest value in a list; for use in MTStepdown.m

lars3.m:
  Computes lasso path for use in MTknockoff.m

makeParams_paper.m:
  Generates parameter matrix for use in fwer_exper3.m

MTHolm.m:
  Performs Holm's procedure for k-FWER control

MTknockoff.m:
  Performs knockoffs procedure for k-FWER control

MTStepdown.m:
  Performs generic stepdown procedure for k-FWER control

MTStepup.m:
  Performs stepup procedure for k-FWER control