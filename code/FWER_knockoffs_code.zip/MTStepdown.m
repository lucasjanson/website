function [R, threshs] = MTStepdown(y, X, sigma, alpha, k, threshs, nsim, modified, cov, cor, knsig)
%% Returns indices of coefficients rejected by Algorithm 2.1 of Romano_Wolf-2007
% with optional modification of Remark 2.1, applied to the OLS p-values of y regressed on X.

if nargin < 11, knsig = true; end
if nargin < 9
    XtX = X'*X; 
    cov = inv(XtX);
    cor = cov ./ (sqrt(diag(cov)) * sqrt(diag(cov))');
end
if nargin < 8, modified = true; end
p = size(X,2);
n = size(X,1);

R = [];
ols = cov*(X'*y);
z = ols ./ (sigma*sqrt(diag(cov)));
if ~knsig % this makes z into a t-stat
    sigmahat = sqrt(sum((y-X*ols).^2)/(n-p));
    z = z*sigma/sigmahat;
end
[z_ord, ind] = sort(abs(z), 'descend');
bitmap = ones(1,p);
for i = 1:p
    [ia, ib] = ismember(bitmap, threshs(:, 1:p), 'rows');
    i_eff = sum(~bitmap)+1;
    if i_eff > p, break; end
    if ia == 0
        sim_kth = nan(nsim,1);
        if isempty(R),
            sims = mvnrnd(zeros(1,p), cor, nsim);
            if ~knsig, sims = bsxfun(@rdivide, sims, sqrt(chi2rnd(n-p,nsim,1)/(n-p))); end
            for m = 1:nsim
                sim_kth(m) = -kthvalue(-abs(sims(m, :)), k);
            end
            thresh = quantile(sim_kth, 1-alpha);
        else
            thresh = 0;
            ind_poss = nchoosek(R, k-1);
            for j = 1:size(ind_poss, 1)
                ind_sim = [ind_poss(j,:) ind(i_eff:p)'];
                sims = mvnrnd(zeros(1,p-i_eff+k), cor(ind_sim, ind_sim), nsim);
                if ~knsig, sims = bsxfun(@rdivide, sims, sqrt(chi2rnd(n-p,nsim,1)/(n-p))); end
                for m = 1:nsim
                    sim_kth(m) = -kthvalue(-abs(sims(m, :)), k);
                end
                thresh = max(quantile(sim_kth, 1-alpha), thresh);
            end
        end
        threshs = [threshs; bitmap thresh];
    else
        thresh = threshs(ib, p+1);
    end
    if i == 1
        inds_rej = ind(1:find(z_ord > thresh, 1, 'last'));
        R = [R inds_rej'];
        if length(inds_rej) < k, break; end
    else
        inds_rej = ind(1:find(z_ord > thresh, 1, 'last'));
        inds_rej = setdiff(inds_rej, R);
        R = [R inds_rej'];
        if isempty(inds_rej), break; end
    end
    bitmap(inds_rej) = 0;
end
if length(R) < k-1 && modified, R = ind(1:(k-1))'; end
end