% Self-contained script to run simulations of CIs adapted from Dicker (2014)

% Define parameter values
m = 10^4;
p = 10^4;
ns = 10.^[2 3 4];
invlogit10rho = -2:2;
rhos = 10.^invlogit10rho./(1+10.^invlogit10rho);
total = 10^4;
alpha = 0.05;

% Initialize results arrays
DTHbounds = nan(length(ns),length(rhos),m,2);
DSGbounds = nan(length(ns),length(rhos),m,2);
DTHcoverage = nan(length(ns),length(rhos),m);
DSGcoverage = nan(length(ns),length(rhos),m);

tic
for k = 1:m
    for i = 1:length(ns)
        n = ns(i);
        X = normrnd(0,1,n,p);
        for j = 1:length(rhos)
            rho = rhos(j);
            
            % Specify run-specific parameters
            th = normrnd(0,1,p,1);
            theta2 = total*rho;
            theta = sqrt(theta2)*th./norm(th,2);
            sigma2 = total*(1-rho);
            
            % Simulate response
            y = X*theta + sqrt(sigma2)*normrnd(0,1,n,1);
            
            % Compute CIs for \theta^2 and \sigma^2
            Xty_norm = sum((X'*y).^2); y_norm = sum(y.^2);
            dth_hat = (Xty_norm - p*y_norm)/(n*(n+1));
            dsg_hat = ((p+n+1)*y_norm - Xty_norm)/(n*(n+1));
            DTHbounds(i,j,k,:) = dth_hat + sqrt(2*((p/n)*(dth_hat+dsg_hat)^2 + dsg_hat^2 + dth_hat^2)/n)*[norminv(alpha/2) norminv(1-alpha/2)];
            DSGbounds(i,j,k,:) = dsg_hat + sqrt(2*((1+p/n)*(dsg_hat+dth_hat)^2 - dsg_hat^2 + 3*dth_hat^2)/n)*[norminv(alpha/2) norminv(1-alpha/2)];
            DTHcoverage(i,j,k) = DTHbounds(i,j,k,1) <= theta2 & DTHbounds(i,j,k,2) >= theta2;
            DSGcoverage(i,j,k) = DSGbounds(i,j,k,1) <= sigma2 & DSGbounds(i,j,k,2) >= sigma2;
        end
    end
    subruntime = toc;
    if mod(k,100) == 0, fprintf(['Simulation ' num2str(k) ' Complete, runtime = ' num2str(subruntime) '\n']), end
end
toc