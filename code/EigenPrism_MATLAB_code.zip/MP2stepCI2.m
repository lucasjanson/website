function x = MP2stepCI2(th_hat, th_sg_hat, d, p, U, y, alpha)
n = length(y);

lambda = d.^2/p;
rho = th_hat/th_sg_hat;
std_i = sqrt(2)*th_sg_hat*(lambda*rho + 1 - rho);
cvx_begin quiet
variable w(n) 
minimize norm(w .* std_i)
subject to
    sum(w) == 0;
    sum(w .* lambda) == 1;
cvx_end

th_hat_new = sum(w .* (U'*y).^2);
x = th_hat_new + sqrt(max(norm(w .* std_i)^2 - 2*th_hat_new^2/(p+2),0))*[norminv(alpha/2) norminv(1-alpha/2)];