%% Note the data used is not publicly available, but can be requested from 
% the dbGaP database (accession number phs000276.v2.p1)

tic

% 'design_details.mat' contains:
%   'prune' which specifies columns to drop
%   'chrom' which corresponds columns with chromosomes
%   'pos' which corresponds columns with position within chromosome
load('design_details.mat')
ind = setdiff(1:p,prune);
[map,ordering] = sortrows([chrom pos],[1 2]);
ind = ind(ordering(map(:,1)<=22)); %now X(:,ind) will be sorted
nchrom = length(unique(map(:,1)));
p = length(ind);

% Load and standardize columns of X (none should be all zeros)
% Some of the processing described in the paper has already been applied
load('X.mat')
Xf = full(X(:,ind));
n = size(X,1);
muf = mean(Xf);
subtime = toc; fprintf(['number of zero means in raw data = ' num2str(sum(muf==0)) ', time = ' num2str(round(subtime/60)) ' min\n']);
Xf = bsxfun(@minus, Xf, muf);
sgf = sqrt(mean(Xf.^2));
sgf(sgf==0) = 1;
Xf = bsxfun(@rdivide, Xf, sgf);

% Load CVX
cd cvx %this folder should be wherever cvx is stored
cvx_setup;
cd ..

alpha = 0.05; %CI significance level

% Load struct of phenotype data and adjust some data types
load('Y.mat')
sex = double(Y.SEX==1);
pill = double(Y.Pills31==1);
preg = double(Y.ZT20==1);
nuis = [ones(n,1) sex pill preg];
diab = double(Y.a10atc~=0);
fast = double(Y.FASTING_STATUS==0);
weightdir = double(Y.PAILAHDE==1);
names = fieldnames(Y);

% Specify which phenotypes not to analyze
skipind = [1 2 3 4 6 9 13 14 15 16 17 18 20 21 22];

% Initialize variables to store results
hbounds = nan(length(names)-length(skipind),2);
nsample = nan(length(names)-length(skipind),1);

i=0;
for j = 1:length(names)
  if any(skipind==j), continue; end
  i = i+1;
  y = double(Y.(names{j}));

  % Clean data according to procedure in paper
  bad_yind = find(isnan(y));
  if any(strcmp({'FS_TRIGL','FS_KOL_H','FS_KOL_L','FB_GLUK','FS_INS'},names{j}))
    bad_yind = union(bad_yind,find(diab==1 | fast==0));
  end
  if any(strcmp({'FS_TRIGL','FS_KOL_H','FS_KOL_L'},names{j}))
    bad_yind = union(bad_yind,find(preg==1));
    notnan = find(~isnan(y));
    ytmp = y(notnan); nuistmp = nuis(notnan,:);
    resid = ytmp-nuistmp*inv(nuistmp'*nuistmp)*nuistmp'*ytmp;
    bigresid = find(abs(resid/std(resid))>3);
    bad_yind = union(bad_yind,notnan(bigresid));
  end
  if strcmp('BMI',names{j})
    bad_yind = union(bad_yind,find(weightdir==0));
  end
  yind = setdiff(1:n,bad_yind);
  y = y(yind);
  subtime = toc; fprintf(['subjects excluded for ' names{j} ' after ' num2str(round(subtime/60)) ' min\n']);

  % Compute SVD for EigenPrism
  [U,D,V] = svd(Xf(yind,:),'econ');
  subtime = toc; fprintf(['SVD for ' names{j} ' computed after ' num2str(round(subtime/60)) ' min\n']);

  % Compute quantities for constraints and optimization
  d = diag(D);
  lambda = d.^2/size(Xf,2);
  n2 = length(y);
  numbig = 100;
  bigind = diag([ones(1,numbig) zeros(1,n2-numbig)]);
  smallind = diag(double(lambda == lambda(end)));
  nsample(i) = n2;
  fprintf([names{j} ' retained ' num2str(n2) ' subjects\n']);

  % Find w for EigenPrism
  cvx_begin quiet
  variable t
  variable w(n2)
  minimize t
  subject to
      sum(w) == 0;
      sum(w .* lambda) == 1;
      norm([w; (t/2-1)/2]) <= (t/2+1)/2;
      norm([w .* lambda; (t/2-1)/2]) <= (t/2+1)/2;
      bigind * w == 0;
      smallind * w == 0;
  cvx_end
  w_th = w;
  var_th = t;

  % Transform some variables
  if strcmp('crp3dec',names{j}), y(y==0) = 0.002; end
  if any(strcmp({'FS_TRIGL','BMI','FB_GLUK','FS_INS','crp3dec'},names{j})), y = log(y); end

  % Regress out other variables and de-mean
  nuistmp = nuis(yind,:);
  if strcmp(names{j},'ZT27'), nuistmp = nuistmp(:,1:2); end
  if any(strcmp({'FS_TRIGL','FS_KOL_H','FS_KOL_L'},names{j})) nuistmp = nuistmp(:,1:3); end
  y = y-nuistmp*inv(nuistmp'*nuistmp)*nuistmp'*y;

  % Compute EigenPrism estimates and signal-to-noise ratio CI
  th_hat = sum(w_th .* (U'*y).^2);
  tot_hat = mean(y.^2);
  hbounds(i,:) = (th_hat + tot_hat * sqrt(var_th)*[norminv(alpha/2) norminv(1-alpha/2)])/tot_hat;
  subtime = toc; fprintf(['Heritability computed for ' names{j} ' after ' num2str(round(subtime/60)) ' min\n']);
end

% Save a few columns of V to check for Gaussianity
[~,~,V] = svd(Xf,'econ');
Vsub = V(:,[1:5 floor(size(V,2)/2) size(V,2)-1 size(V,2)]);

% Save output
save(['finlandherit_diag_final.mat'],'hbounds','names', 'nsample','Vsub')
fprintf('finished finland heritability\n')
