## Fits QUARTS algorithm to NH paleoclimate proxy data and computes nonparametric bootstrap uncertainty.
## Both the values of 'order' and 'PCs' were chosen in a data-driven manner described in the paper.
## Although the AR order is a variable set to 1, this code will only work for this value.

# On my laptop (Lenovo T520 2.6GHz, 8MB RAM), some running times:
# boot = 200, PCs = 9, order = 1, maxit = 500, years = 998:1998 ==> 250sec
# boot = 2000, PCs = 9, order = 1, maxit = 500, years = 998:1998 ==> 2000sec
library(quantreg)
source("paleoFunctions.R")

## Define constant variables
boot = 20
breaks = c(1850, 1865, 1879, 1894, 1908, 1923, 1937, 1952, 1966, 1981, 1995)
startyear = 998
endyear = 1998
years = startyear:endyear
maxit = 500
tol = 1e-2
order = 1
taus = 0.5
PCs = 9

## Initialize variables
fit = list()
boots = list()
innov = list()
sds = list()
coef = list()
for(tau in taus){
	fit[[paste(tau)]] = matrix(startyear:(endyear - order), endyear - startyear + 1 - order, 2)
	boots[[paste(tau)]] = matrix(NA, endyear - startyear + 1 - order, boot)
	sds[[paste(tau)]] = rep(0, length(breaks) - 1)
}

## Read in data
proxies = readProxies()

# Uncomment to get a vector of the proxy names (or at least their identifiers)
#proxnames = findproxnames(proxies, startyear = startyear)

# Uncomment to restrict to a certain type of proxy (tree-width = 9000)
#proxtypes = readProxTypes()
#prox = 9000
#proxnames = proxnames[proxtypes == prox]

instruments = readInstruments()
proxies = proxies[proxies[ , 1] >= startyear & proxies[ , 1] <= endyear, ]
instruments = instruments[instruments[ , 1] <= endyear, ]
y = instruments[ , 3]
years.cal = instruments[ , 1]
X = proxies[ , !is.na(proxies[proxies[ , 1] == startyear, ]) & !is.na(proxies[proxies[ , 1] == endyear])]

# Uncomment to restrict to a certain type of proxy
#X = proxies[ , c(TRUE, proxtypes == prox)]

X.cal = X[X[ , 1] %in% instruments[ , 1], -1]
X.cal = cbind(matrix(1, nrow(X.cal), 1), X.cal)
X[ , 1] = rep(1, nrow(X))
yX = cbind(y, X.cal)
eig = eigen(cor(X.cal[ , -1]), symmetric = TRUE)

## Fit QUARTS and compute innovations
for(tau in taus){
	coef[[paste(tau)]] = QARpcqr.fixed(nrow(yX):1, yX, pc = PCs[taus == tau], eig = eig, tau = tau, order = order, tol = tol, maxit = maxit)
	e.0 = y[length(y)] - X.cal[nrow(X.cal), ] %*% coef[[paste(tau)]]$coef
	for(i in nrow(fit[[paste(tau)]]):(nrow(fit[[paste(tau)]]) - length(y) + 1 + order)){
		fit[[paste(tau)]][i, 2] = X[i, ] %*% coef[[paste(tau)]]$coef + coef[[paste(tau)]]$phi * e.0
		e.0 = y[i - (nrow(X) - length(y))] - X[i, ] %*% coef[[paste(tau)]]$coef
	}
	innov[[paste(tau)]] = y[-length(y)] - fit[[paste(tau)]][fit[[paste(tau)]][ , 1] >= 1850, 2]
	fit[[paste(tau)]][nrow(fit[[paste(tau)]]) - length(y) + order, 2] = X[nrow(fit[[paste(tau)]]) - length(y) + order, ] %*% coef[[paste(tau)]]$coef + coef[[paste(tau)]]$phi * e.0
	e.0 = coef[[paste(tau)]]$phi * e.0 + mean(innov[[paste(tau)]])
	for(i in (nrow(fit[[paste(tau)]]) - length(y) + order - 1):1){
		fit[[paste(tau)]][i, 2] = X[i, ] %*% coef[[paste(tau)]]$coef + coef[[paste(tau)]]$phi * e.0
		e.0 = coef[[paste(tau)]]$phi * e.0 + mean(innov[[paste(tau)]])
	}
}

## Calculate scaling factor for innovation standard deviation
for(j in 1:(length(breaks) - 1)){
	yX.1 = cbind(y[years.cal >= breaks[j + 1]], X.cal[years.cal >= breaks[j + 1], ])
	yX.2 = cbind(y[years.cal < breaks[j]], X.cal[years.cal < breaks[j], ])
	if(j == length(breaks) - 1){yX.1 = yX.1[FALSE, ]}
	fit.sd = list()
	coef.sd = list()
	for(tau in taus){
		fit.sd[[paste(tau)]] = matrix(startyear:(endyear - order), endyear - startyear + 1 - order, 2)
		coef.sd[[paste(tau)]] = QARpcqr.fixed.2(nrow(yX.1):1, yX.1, nrow(yX.2):1, yX.2, pc = PCs[taus == tau], eig = eig, tau = tau, order = order, tol = tol, maxit = maxit)
		e.0 = y[length(y)] - X.cal[nrow(X.cal), ] %*% coef.sd[[paste(tau)]]$coef
		for(i in nrow(fit.sd[[paste(tau)]]):(nrow(fit.sd[[paste(tau)]]) - length(y) + 1 + order)){
			fit.sd[[paste(tau)]][i, 2] = X[i, ] %*% coef.sd[[paste(tau)]]$coef + coef.sd[[paste(tau)]]$phi * e.0
			e.0 = y[i - (nrow(X) - length(y))] - X[i, ] %*% coef.sd[[paste(tau)]]$coef
		}
		sds[[paste(tau)]][j] = sqrt(sum((y[years.cal >= breaks[j] & years.cal < breaks[j + 1]] - fit.sd[[paste(tau)]][(nrow(fit.sd[[paste(tau)]]) - length(y) + 1 + order + breaks[j] - breaks[1]):(nrow(fit.sd[[paste(tau)]]) - length(y) + breaks[j + 1] - breaks[1] + order), 2])^2) / (breaks[j + 1] - breaks[j] - 1))
	}
}

## Rescale innovations to correct for overfitting in the nonparametric bootstrap
innov.rescaled = list()
for(tau in taus){
	innov.rescaled[[paste(tau)]] = mean(innov[[paste(tau)]]) + (mean(sds[[paste(tau)]]) / sd(innov[[paste(tau)]])) * (innov[[paste(tau)]] - mean(innov[[paste(tau)]]))
}

## Computes bootstrap sample by resampling temperature realizations from quantile model
for(j in 1:boot){
	coef.boot = list()
	for(tau in taus){
		basemodel = X.cal %*% coef[[paste(tau)]]$coef
		innovs = innov.rescaled[[paste(tau)]][sample(length(innov.rescaled[[paste(tau)]]), length(basemodel), replace = T)]
		innovs.start = innov.rescaled[[paste(tau)]][sample(length(innov.rescaled[[paste(tau)]]), 10, replace = T)]
		residuals = arima.sim(model = list(ar = c(coef[[paste(tau)]]$phi)), n = length(basemodel), innov = innovs, n.start = 10, start.innov = innovs.start)
		y.boot = basemodel + residuals[length(residuals):1]
		yX.boot = cbind(y.boot, X.cal)
		coef.boot[[paste(tau)]] = QARpcqr.fixed(nrow(yX.boot):1, yX.boot, pc = PCs[taus == tau], eig = eig, tau = tau, order = order, tol = tol, maxit = maxit)
		if(is.na(coef.boot[[paste(tau)]]$coef[1])) next
		for(i in nrow(boots[[paste(tau)]]):(nrow(boots[[paste(tau)]]) - length(y.boot) + 1 + order)){
			e.0 = y.boot[i - (nrow(X) - length(y))] - X[i, ] %*% coef.boot[[paste(tau)]]$coef
			boots[[paste(tau)]][i, j] = X[i, ] %*% coef.boot[[paste(tau)]]$coef + e.0
		}
		for(i in (nrow(boots[[paste(tau)]]) - length(y.boot) + order):1){
			e.0 = coef.boot[[paste(tau)]]$phi * e.0 + rnorm(1, mean(innov[[paste(tau)]]), mean(sds[[paste(tau)]]))
			boots[[paste(tau)]][i, j] = X[i, ] %*% coef.boot[[paste(tau)]]$coef + e.0
		}
	}
}
for(tau in taus){boots[[paste(tau)]] = boots[[paste(tau)]][!is.na(boots[[paste(tau)]][ , 1]), ]}

## Compute a few specific bootstrap quantiles
median.boot = list()
top.boot = list()
bottom.boot = list()
for(tau in taus){
	bottom.boot[[paste(tau)]] = apply(boots[[paste(tau)]], 1, fun <- function(x){quantile(x, probs = 0.025)})
	median.boot[[paste(tau)]] = apply(boots[[paste(tau)]], 1, fun <- function(x){median(x)})
	top.boot[[paste(tau)]] = apply(boots[[paste(tau)]], 1, fun <- function(x){quantile(x, probs = 0.975)})
}

## Plot output, assuming tau = 0.5
df = 115
plot(fit[["0.5"]][ , 1], smooth.spline(fit[["0.5"]][ , 2], df = df)$y, lwd = 2, main = "Smoothed Millennial Reconstruction with 95% Pathwise Prediction Intervals", xlab = "Year", ylab = "Temperature Anomaly (K)", type = "l", col = "black", ylim = range(-1, 0.5))
for(i in 1:length(fit[["0.5"]][ , 1])){lines(rep(fit[["0.5"]][i, 1], 2), c(smooth.spline(bottom.boot[["0.5"]])$y[i], smooth.spline(top.boot[["0.5"]])$y[i]), col = rgb(0.6, 0.6, 0.6, 0.3))}



