# Finds some dimensions of infilled proxy data.  Should output [2003 1998 -8855 1799 10853 428 1209] ([... 1037] for NH=T).
# root should be directory containing all downloaded proxies
sizeProxies <- function(root = "C:/Users/Lucas Janson/Documents/Research/A_allproxy1209/", NH = TRUE){
	files = list.files(root)
	max = 0
	minmax = 2000
	min = 2000
	maxmin = 0
	lengths = matrix(NA, length(files), 1)
	for(i in 1:length(files)){
		p = read.table(paste(root, files[i], sep = ""))
		if(NH && p[2, 1] < 0) next
		lengths[i] = nrow(p) - 4
		if(p[nrow(p), 1] > max){max = p[nrow(p), 1]}
		if(p[nrow(p), 1] < minmax){minmax = p[nrow(p), 1]}
		if(p[4, 1] < min){min = p[4, 1]}
		if(p[4, 1] > maxmin){maxmin = p[4, 1]}
	}
	result = c(max, minmax, min, maxmin, max(lengths, na.rm = T), median(lengths, na.rm = T), length(lengths[!is.na(lengths)]))
	hist(lengths, breaks = 55)
	result
}

# Reads in proxy data series from file.
readProxies <- function(max = 2003, min = -8855, root = "C:/Users/Lucas Janson/Documents/Research/A_allproxy1209/", NH = TRUE){
	files = list.files(root)
	result = matrix(NA, max - min + 1, length(files) + 1)
	result[ , 1]  = min:max
	for(i in 1:length(files)){
		p = read.table(paste(root, files[i], sep = ""))
		if(NH && p[2, 1] < 0) next
		overlap = match(result[ , 1], p[4:nrow(p), 1])
		indices = overlap[!is.na(overlap)]
		result[result[ , 1] %in% p[4:nrow(p), 1], i + 1] = p[3 + indices, 2]
	}
	result[ , apply(result, 2, fun <- function(x){any(!is.na(x))})]
}

# Reads proxy types from files (9000 = tree-width).
readProxTypes <- function(root = "C:/Users/Lucas Janson/Documents/Research/A_allproxy1209/", NH = TRUE){
	files = list.files(root)
	result = rep(NA, length(files), 1)
	for(i in 1:length(files)){
		p = read.table(paste(root, files[i], sep = ""))
		if(NH && p[2, 1] < 0) next
		result[i] = p[3, 1]
	}
	result[!is.na(result)]
}

# Reads proxy lattitude and longitudes from files.
readProxLocs <- function(root = "C:/Users/Lucas Janson/Documents/Research/A_allproxy1209/", NH = TRUE){
	files = list.files(root)
	result = matrix(NA, length(files), 2)
	for(i in 1:length(files)){
		p = read.table(paste(root, files[i], sep = ""))
		if(NH && p[2, 1] < 0) next
		result[i, ] = t(p[1:2, 1])
	}
	result[!is.na(result[ , 1]), ]
}

# Reads in instrumental data set from files. root should be directory containing iCRU_NH_reform.txt and iHAD_NH_reform.txt
readInstruments <- function(max = 2006, min = 1850, root = "C:\Users\Lucas Janson\Documents\Research\Instrumental"){
	files = list.files(root)
	result = matrix(NA, max - min + 1, length(files) + 1)
	colnames(result)[2:ncol(result)] = files
	result[ , 1] = min:max
	for(i in 1:length(files)){
		p = read.table(paste(root, files[i], sep = ""))
		result[ , i + 1] = p[ , 2]
	}
	result
}

# Reads proxy names; currently only works for Northern Hemisphere proxies.
findproxnames <- function(proxies, startyear = 998, endyear = 1998, root = "C:/Users/Lucas Janson/Documents/Research/A_allproxy1209/"){
	proxbool = !is.na(proxies[proxies[ , 1] == startyear, ]) & !is.na(proxies[proxies[ , 1] == endyear])
	proxnum = (1:1038)[proxbool]
	proxnum = proxnum[-1] - 1
	files = list.files(root)
	NHfiles = c()
	for(i in 1:length(files)){
		p = read.table(paste(root, files[i], sep = ""))
		if(p[2, 1] < 0) next
		NHfiles = c(NHfiles, files[i])
	}
	NHfiles = unlist(strsplit(NHfiles, ".", fixed = T))[seq(1, 2 * length(NHfiles), 2)]
	NHfiles[proxnum]
}

# Fits principle components quantile regression for a fixed number of principle components.
pcqr.fixed <- function(yX, eig = 0, pc, tau = 0.5){
	n = nrow(yX)
	X = yX[ , 3:ncol(yX)]
	e = list()
	if(length(eig) == 1){
		Cor = cor(X)
		e = eigen(Cor, symmetric = T)
	} else {e = eig}
	S = e$vectors[ , e$values >= 1e-6]
	yX.pc = cbind(yX[ , 1:2], scale(X) %*% S)
	k = pc
	finalfit = rq(yX.pc[ , 1] ~ yX.pc[ , 3:(k + 2)], tau = tau)
	unrotated = S[ , 1:k] %*% matrix(finalfit$coefficients[-1], k, 1)
	unscaled = unrotated / apply(X, 2, sd)
	remeaned = finalfit$coefficients[1] - colMeans(X) %*% unscaled
	rbind(remeaned, unscaled)
}

# Applies polynomial of backshift operators, with coefficients phi.
backshift.vec <- function(x, phi){
	p = length(phi)
	x.ext = c(rep(0, p), x)
	for(i in 1:p){
		x = x - phi[i] * x.ext[(p - i + 1):(length(x.ext) - i)]
	}
	x
}

# Fits an autoregressive process in the quantile regression framework.
qar = function(ts, tau = 0.5, order = 2){
	X = matrix(0, length(ts) - order, order)
	for(i in 1:order){
		X[ , i] = ts[(order - i + 1):(length(ts) - i)]
	}
	result = rq(ts[-(1:order)] ~ X, tau = tau)$coefficients
	result
}

# Fits two autoregressive processes with the same parameters in the quantile regression framework.
qar.2 <- function(ts.1, ts.2, tau = 0.5, order = 2){
	X.1 = matrix(0, length(ts.1) - order, order)
	X.2 = matrix(0, length(ts.2) - order, order)
	for(i in 1:order){
		X.1[ , i] = ts.1[(order - i + 1):(length(ts.1) - i)]
		X.2[ , i] = ts.2[(order - i + 1):(length(ts.2) - i)]
	}
	ts = c(ts.1[-(1:order)], ts.2[-(1:order)])
	X = rbind(X.1, X.2)
	rq(ts ~ X, tau = tau)$coefficients
}

# Fits QUARTS algorithm with prespecified number of PCs and AR order
QARpcqr.fixed <- function(index, data, pc, eig = 0, tau = 0.5, order = 2, tol = 1e-1, maxit = 200){
	yX = data[index, ]
	n = nrow(yX)
	X = yX[ , 2:ncol(yX)]
	y = yX[ , 1]
	fit = pcqr.fixed(yX, eig = eig, pc, tau)
	alpha = 0
	phi = rep(0, order)
	nit = 0
	path.coef = matrix(fit, ncol(X), 1)
	path.phi = matrix(phi, order, 1)
	e = rep(0, length(y))
	while(TRUE){
		y1 = y - (e - backshift.vec(e, phi))
		fit1 = pcqr.fixed(cbind(y1, X)[-(1:order), ], eig = eig, pc, tau)
		e = y - X %*% fit1
		qarfit = qar(e, tau = tau, order = order)
		alpha1 = qarfit[1]
		phi1 = qarfit[-1]
		if(phi1 == 0) break
		path.coef = cbind(path.coef, matrix(fit1, ncol(X), 1))
		path.phi = cbind(path.phi, matrix(phi1, order, 1))
		if(!any(abs((fit1 - fit) / fit) > tol) & !any(abs((phi1 - phi) / phi) > tol) & (abs((alpha1 - alpha) / alpha) < tol | abs(alpha1 / fit1[1]) < tol)) break
		nit = nit + 1
		if(nit > maxit) break
		fit = fit1
		phi = phi1
		alpha = alpha1
	}
	result = list()
	result$phi = phi1
	result$coef = fit1
	result$coef[1] = result$coef[1] + alpha1
	result$nit = nit
	result$path.coef = path.coef
	result$path.phi = path.phi
	if(phi1 == 0) result$coef  = rep(NA, length(result$coef))
	result
}

# Fits QUARTS algorithm with the same parameters on two datasets.
QARpcqr.fixed.2 <- function(index.1, data.1, index.2, data.2, pc, eig = 0, tau = 0.5, order = 2, tol = 1e-1, maxit = 200){
	if(nrow(data.1) == 0){return(QARpcqr.fixed(index.2, data.2, pc, eig = eig, tau, order, tol, maxit))}
	if(nrow(data.2) == 0){return(QARpcqr.fixed(index.1, data.1, pc, eig = eig, tau, order, tol, maxit))}
	yX.1 = data.1[index.1, ]
	yX.2 = data.2[index.2, ]
	X.1 = yX.1[ , 2:ncol(yX.1)]
	X.2 = yX.2[ , 2:ncol(yX.2)]
	y.1 = yX.1[ , 1]
	y.2 = yX.2[ , 1]
	fit = pcqr.fixed(rbind(yX.1, yX.2), eig = eig, pc, tau)
	alpha = 0
	phi = rep(0, order)
	nit = 0
#	path.coef = matrix(fit, ncol(X), 1)
#	path.phi = matrix(phi, order, 1)
	e.1 = rep(0, length(y.1))
	e.2 = rep(0, length(y.2))
	while(TRUE){
		y1.1 = y.1 - (e.1 - backshift.vec(e.1, phi))
		y1.2 = y.2 - (e.2 - backshift.vec(e.2, phi))
		y1 = c(y1.1[-(1:order)], y1.2[-(1:order)])
		X1 = rbind(X.1[-(1:order), ],X.2[-(1:order), ])
		fit1 = pcqr.fixed(cbind(y1, X1), eig = eig, pc, tau)
		e.1 = y.1 - X.1 %*% fit1
		e.2 = y.2 - X.2 %*% fit1
		qarfit = qar.2(e.1, e.2, tau = tau, order = order)
		alpha1 = qarfit[1]
		phi1 = qarfit[-1]
#		path.coef = cbind(path.coef, matrix(fit1, ncol(X), 1))
#		path.phi = cbind(path.phi, matrix(phi1, order, 1))
		if(!any(abs((fit1 - fit) / fit) > tol) & !any(abs((phi1 - phi) / phi) > tol) & (abs((alpha1 - alpha) / alpha) < tol | abs(alpha1 / fit1[1]) < tol)) break
		nit = nit + 1
		if(nit > maxit) break
		fit = fit1
		phi = phi1
		alpha = alpha1
	}
	result = list()
	result$phi = phi1
	result$coef = fit1
	result$coef[1] = result$coef[1] + alpha1
	result$nit = nit
#	result$path.coef = path.coef
#	result$path.phi = path.phi
	result
}
