EigenPrism: Inference for High-Dimensional Signal-to-Noise Ratios
by Lucas Janson, Rina Barber, Emmanuel Candes
Code also available on first author's website: http://statweb.stanford.edu/~ljanson/

EigenPrism.R:
  Function for running EigenPrism procedure for any of the three target parameters in the paper, including diagnostic checks

compare_to_Bayes.m: 
  Runs simulations comparing CI widths between EigenPrism and Bayes for a given prior

EigenPrism_sim.m:
  Runs simulations checking coverage and widths of EigenPrism CIs

makeParams.m: 
  Generates parameter structs for the simulations run by compare_to_Bayes.m and EigenPrism_sim.m

Dicker_sim.m:
  Runs simulations checking coverage and widths of CIs derived from Dicker (2014)

sigma2_inference.R:
  Runs simulations checking coverage and widths of refitted cross-validation and scaled lasso CIs (using R package scalreg)

makeParams.R:
  Generates parameter data frame for the simulations run by sigma2_inference.R

MP2stepCI2.m: 
  Performs EigenPrism 2-step procedure to construct CIs

NFBC1966_analysis.m:
  Analyzes Northern Finland Birth Cohort data set (data itself cannot be shared due to privacy)

tiltNormCDF.m, tiltNormCDFinv.m: 
  Short functions needed for Gibbs sampler in compare_to_Bayes.m

nearestSPD.m:
  Required but not written by me and is *NOT* included, but can be downloaded from http://www.mathworks.com/matlabcentral/fileexchange/42885-nearestspd
