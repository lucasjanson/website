%% Parameters for width comparison with Bayes (Figure 4b)
p.mm = [50]';
p.burn = [20]';
p.inter = [8]';
p.n = [100 500 1000 5000 10000]';
p.p = [10000]';
p.m = [300]';
p.alpha = [0.2]';
p.param_shape_sigma2 = [14]';
p.scale_sigma2 = [1/20000]';
p.lambda_M = [5]';
repeats = 20;

p = struct2cell(p);

len = nan(length(p), 1);
for i = 1:length(p), len(i) = length(p{i}); end
n = prod(len);

for i = 1:(length(p)-1)
    for j = 1:i
		p{j} = repmat(p{j}, len(i+1), 1);
    end
    for j = (i+1):length(p)
		p{j} = vec(repmat(p{j}', len(i), 1));
    end
end
params = cell2mat(p');
any(any(isnan(params)))

params = reshape(repmat(params,1,repeats)', size(params,2),size(params,1)*repeats)';

save('paramsBayes_final.mat', 'params')

%% Parameters for robustness results (Figure 9)
% 12GB required for each; covers marginal moments, marginal sparsity, correlations, 
%  and theta both dense and sparse, with version 1-18
%  note versions 7,8,16,17 should have 50 runs, while others should have 1
designs = [3 2 12, 5 4 7, 9 10 11];
sparsities = [1, 0.01];
versions = 1:(length(designs)*length(sparsities));

params.mm = [500]';
params.ns = [1000]';
params.p = [10000]'; %can only have one of these
params.alpha = [0.05]';
params.total = [10000]';
params.invlogit10rho = [-2:2]';
params.corr = [0]';
params.nBeta = [20]';

for j = 1:length(sparsities)
    for i = 1:length(designs)
        params.version = versions((j-1)*length(designs)+i);
        params.design = designs(i); %for now can only have 1
        params.sparsity = sparsities(j); %sparsity=1 is no sparsity
        if ismember(designs(i),[9 10])
            params.Xper = 10;
        else
            params.Xper = 500;
        end
        version_num = params.version;
        
        save(['paramsEP' num2str(version_num) '.mat'], 'params')
    end
end
nJobsToRun = length(params.ns)*params.mm/params.Xper

%% Parameters for EigenPrism results as function of sparsity (Figure 7)
% 8GB required for each
sparsities = [0.001 0.005 0.01 0.05 0.1];
versions = 19:(18+length(sparsities));

params.mm = [10000]';
params.ns = [500]';
params.p = [1000]'; %sorry, can only have one of these
params.alpha = [0.05]';
params.design = [1]'; %for now can only have 1
params.corr = [0]';
params.nBeta = [1]';
params.Xper = [10000]';

for i = 1:length(sparsities)
    params.version = versions(i); % change this for new experiments
    params.sparsity = sparsities(i); %sparsity=1 is no sparsity
    params.total = 1+params.p*sparsities(i);
    rho = params.p*sparsities(i)/params.total;
    params.invlogit10rho = log10(rho/(1-rho));
    version_num = params.version;
    
    save(['paramsEP' num2str(version_num) '.mat'], 'params')
end

nJobsToRun = length(params.ns)*params.mm/params.Xper
