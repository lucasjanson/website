library(scalreg)

# Must specify variable 'run' to specify which row of parameter matrix to use

# Load problem parameters and generate variables
load('params_sigma2.rdata')
for(i in 1:ncol(params)){
  variable = names(params)[i]
  eval(parse(text = paste(variable, "= params[run, i]")))
}

# Specify other parameters
tic = proc.time()
n = p*n.over.p
nnz = floor(p*spar)
sig = 1
beta = mag*c(rep(1,nnz),rep(0,p-nnz))
gamma = n/4

# Initialize storage vectors
sig2.hat.q = rep(NA, mm)
sig2.rcv = rep(NA, mm)

# Generate scaled lasso and RCV estimates
for(i in 1:mm){
  X = matrix(rnorm(n*p),n,p)
  y = X %*% beta + sig*rnorm(n)
  sig2.hat.q[i] = scalreg(X, y, lam0="quantile")$hsigma^2

  X1 = X[1:(n/2),]; y1 = y[1:(n/2)]
  X2 = X[(n/2+1):n,]; y2 = y[(n/2+1):n]
  w1 = t(X1)%*%y1
  w2 = t(X2)%*%y2
  s1 = sort(w1,decreasing=TRUE,index.return=T)
  s2 = sort(w2,decreasing=TRUE,index.return=T)
  lm1 = lm(y2~0+X2[,s1$ix[1:gamma]])
  lm2 = lm(y1~0+X1[,s2$ix[1:gamma]])
  sigsq1 = sum(lm1$residuals^2)/lm1$df.residual
  sigsq2 = sum(lm2$residuals^2)/lm2$df.residual
  sig2.rcv[i] = mean(c(sigsq1,sigsq2))

  if(i%%10==0) print(paste('run',i,'finished'))
}

# Compute scaled lasso CIs and coverage
bounds.q = cbind(sqrt(sig2.hat.q)/(1+qnorm(1-alpha/2)/sqrt(2*n)),
		 sqrt(sig2.hat.q)/(1+qnorm(alpha/2)/sqrt(2*n)))
coverage.q = mean(sig >= bounds.q[,1] & sig <= bounds.q[,2])

# Compute RCV CIs and coverage
boundsRCV = cbind(sig2.rcv/(1+qnorm(1-alpha/2)*sqrt(2/n)),
		    sig2.rcv/(1+qnorm(alpha/2)*sqrt(2/n)))
coverage.rcv = sig^2 >= boundsRCV[,1] & sig^2 <= boundsRCV[,2]

# Save output
runtime = proc.time() - tic
date = Sys.Date()
save('coverage.q', 'coverage.rcv', 'bounds.q',
     'sig2.hat.q', 'sig2.rcv', 'runtime',
     file = paste('../results/sigEst2/sigmaEst', run, '_date-', date, '.rdata', sep=""))

