% Before running script, define 'run' variable as row of parameter matrix to use

% Load CVX
cd cvx %this folder should be wherever cvx is stored
cvx_setup;
cd ..

% Load parameters of simulation
load('paramsBayes_final')

mm = params(run, 1); %number of simulations

burn = params(run, 2); %MCMC burn-in period
inter = params(run, 3); %MCMC step period

n = params(run, 4); %number of observations
p = params(run, 5); %number of variables
m = params(run, 6); %number of MCMC draws
alpha = params(run, 7); %CI significance level

lambda_M = params(run, 10); %prior lambda for drawing M
shape_sigma2 = params(run, 8); %prior shape for drawing sigma^2
scale_sigma2 = params(run, 9); %prior scale for drawing sigma^2

fprintf(['shape_sigma2 = ' num2str(shape_sigma2) ', scale_sigma2 = ' ...
    num2str(scale_sigma2) ', lambda_M = ' num2str(lambda_M) '\n'])

% Initialize variables to store results
MPbounds = nan(mm, 2);
MPwidths = nan(mm, 1);
MPcoverage = nan(mm, 1);
SGbounds = nan(mm, 2);
SGwidths = nan(mm, 1);
SGcoverage = nan(mm, 1);
BayesBounds = nan(mm, 2);
BayesWidths = nan(mm, 1);
BayesCoverage = nan(mm, 1);
BayesBoundsSG = nan(mm, 2);
BayesWidthsSG = nan(mm, 1);
BayesCoverageSG = nan(mm, 1);
MPknSGbounds = nan(mm, 2);
DTHbounds = nan(mm,2);
DSGbounds = nan(mm,2);

% Set random seed
RandStream.setGlobalStream(RandStream('mt19937ar','seed', sum(1000*clock)*run));
seed = RandStream.getGlobalStream.Seed;

% Draw parameters from priors
true_sigmas2 = 1./gamrnd(shape_sigma2, scale_sigma2, mm, 1);
Zs = normrnd(0, 1, p, mm);
Ms = exprnd(1/lambda_M, mm, 1);
thetas = bsxfun(@times, Zs, sqrt(Ms)');
theta2 = sum(thetas.^2, 1)';

tic

for j = 1:mm
    Xok = false;
    while ~Xok
        X = normrnd(0, 1, n, p);

        % Find w for EigenPrism (for theta)
        [U,D,V] = svd(X);
        d = diag(D);        
        lambda = d.^2/p;
        cvx_begin quiet
        variable t
        variable w(n)
        minimize t
        subject to
            sum(w) == 0;
            sum(w .* lambda) == 1;
            norm([w; (t/2-1)/2])  <= (t/2+1)/2;
            norm([w .* lambda; (t/2-1)/2]) <= (t/2+1)/2;
        cvx_end
        
        w_th = w;
        var_th = t;
        
        if ~strcmp(cvx_status, 'Failed'), Xok = true; end
        
        % Find w for EigenPrism (for sigma)
        cvx_begin quiet
        variable t
        variable w(n)
        minimize t
        subject to
            sum(w) == 1;
            sum(w .* lambda) == 0;
            norm([w; (t/2-1)/2])  <= (t/2+1)/2;
            norm([w .* lambda; (t/2-1)/2]) <= (t/2+1)/2;
        cvx_end
        
        w_sg = w;
        var_sg = t;
        
        if ~strcmp(cvx_status, 'Failed'), Xok = true; end
    end
    y = X*thetas(:,j) + sqrt(true_sigmas2(j))*normrnd(0, 1, n, 1);
    
    % Initialize Gibbs sampler
    z = nan(p, m*inter + burn);
    s2 = Inf*ones(1, m*inter + burn);
    M = Inf*ones(1, m*inter + burn);
    
    z(:,1) = Zs(:,j);
    s2(1) = true_sigmas2(j);
    M(1) = Ms(j);
    
    Xz = X*z(:,1);
    X2 = sum(X.^2, 1);
    Xy = X'*y;
    
    % Run Gibbs sampler
    for i = 2:(m*inter + burn)
        s2(i) = 1/gamrnd(n/2 + shape_sigma2, 1/(norm(y - sqrt(M(i-1))*Xz,2)^2/2 + 1/scale_sigma2));
        zXXz = Xz'*Xz;
        yXz = y'*Xz;
        M(i) = (tiltNormCDFinv(unifrnd(0,1), yXz/(zXXz+2*lambda_M*s2(i)), s2(i)/(zXXz+2*lambda_M*s2(i)), 0.001) + yXz/(zXXz+2*lambda_M*s2(i)))^2;
        for k = 1:p
            z(k,i) = normrnd((sqrt(M(i))*Xy(k)/s2(i) - M(i)*(Xz-z(k,i-1)*X(:,k))'*X(:,k)/s2(i))/(1+M(i)*X2(k)/s2(i)), sqrt(1/(1+M(i)*X2(k)/s2(i))));
            Xz = Xz + (z(k,i)-z(k,i-1))*X(:,k);
        end
        if mod(i, 200) == 0
             subruntime = toc;
%              fprintf(['Simulation ' num2str(j) ', Sample ' num2str(i) ' Complete, runtime = ' num2str(subruntime) '\n'])
         end
    end
    
    % Posterior draws
    bayesian_th = M(burn:inter:end).*sum((z(:,burn:inter:end)).^2, 1);
    bayesian_sg = s2(burn:inter:end);
    
    % EigenPrism Estimates
    th_hat = sum(w_th .* (U'*y).^2);
    sg_hat = sum(w_sg .* (U'*y).^2);

    % EigenPrism theta^2 CIs
    MPbounds(j,:) = th_hat + sum(y.^2)/n * sqrt(var_th)*[norminv(alpha/2) norminv(1-alpha/2)];
    MPcoverage(j) = MPbounds(j,1) <= theta2(j) & MPbounds(j,2) >= theta2(j);
    MPwidths(j) = diff(MPbounds(j,:));
    
    % EigenPrism sigma^2 CIs
    SGbounds(j,:) = sg_hat + sum(y.^2)/n * sqrt(var_sg)*[norminv(alpha/2) norminv(1-alpha/2)];
    SGcoverage(j) = SGbounds(j,1) <= true_sigmas2(j) & SGbounds(j,2) >= true_sigmas2(j);
    SGwidths(j) = diff(SGbounds(j,:));
        
    % Oracle CIs (as if sigma^2 known)
    MPknSGbounds(j,:) = norm(y)^2 ./ [chi2inv(1-alpha/2, n) chi2inv(alpha/2, n)] - true_sigmas2(j);
    
    % Bayes theta^2 CIs
    BayesBounds(j,:) = quantile(bayesian_th, [alpha/2 1-alpha/2]);
    BayesCoverage(j) = BayesBounds(j,1) <= theta2(j) & BayesBounds(j,2) >= theta2(j);
    BayesWidths(j) = diff(BayesBounds(j,:));
    
    % Bayes sigma^2 CIs
    BayesBoundsSG(j,:) = quantile(bayesian_sg, [alpha/2 1-alpha/2]);
    BayesCoverageSG(j) = BayesBoundsSG(j,1) <= true_sigmas2(j) & BayesBoundsSG(j,2) >= true_sigmas2(j);
    BayesWidthsSG(j) = diff(BayesBoundsSG(j,:));
    
    % Dicker (2014) CIs--see Corollary 1 of that paper 
    Xty_norm = sum((X'*y).^2); y_norm = sum(y.^2);
    dth_hat = (Xty_norm - p*y_norm)/(n*(n+1));
    dsg_hat = ((p+n+1)*y_norm - Xty_norm)/(n*(n+1));
    DTHbounds(j,:) = dth_hat + sqrt(2*((p/n)*(dth_hat+dsg_hat)^2 + dsg_hat^2 + dth_hat^2)/n)*[norminv(alpha/2) norminv(1-alpha/2)];
    DSGbounds(j,:) = dsg_hat + sqrt(2*((1+p/n)*(dsg_hat+dth_hat)^2 - dsg_hat^2 + 3*dth_hat^2)/n)*[norminv(alpha/2) norminv(1-alpha/2)];
    
    subruntime = toc;
    if mod(j,1) == 0, fprintf(['Simulation ' num2str(j) ' Complete, runtime = ' num2str(subruntime) '\n']), end  
end

% Clip CIs at 0
MPbounds(:,1) = max(MPbounds(:,1),0);
MPknSGbounds(:,1) = max(MPknSGbounds(:,1),0);
SGbounds(:,1) = max(SGbounds(:,1),0);

% Summarize some output in console
fprintf(['Avg rel MP width was ' num2str(mean(MPwidths ./ theta2)) ' +/- ' ...
    num2str(std(MPwidths ./ theta2)/sqrt(mm)) ' with coverage ' num2str(mean(MPcoverage)) ...
    ' +/- ' num2str(sqrt(alpha*(1-alpha)/mm)) '.\n'])
fprintf(['Median rel MP width was ' num2str(median(MPwidths ./ theta2)) ' +/- ' ...
    num2str(1/(2*ksdensity(MPwidths ./ theta2, median(MPwidths./theta2))*sqrt(mm))) ' with coverage ' num2str(mean(MPcoverage)) ...
    ' +/- ' num2str(sqrt(alpha*(1-alpha)/mm)) '.\n'])
fprintf(['Avg rel Bayes width was ' num2str(mean(BayesWidths ./ theta2)) ' +/- ' ...
    num2str(std(BayesWidths ./ theta2)/sqrt(mm)) ' with coverage ' num2str(mean(BayesCoverage)) ...
    ' +/- ' num2str(sqrt(alpha*(1-alpha)/mm)) '.\n'])
fprintf(['Avg width inflation was ' num2str(round(100*(mean(MPwidths ./ BayesWidths)-1))) ...
    '%% +/- ' num2str(100*std(MPwidths ./ BayesWidths)/sqrt(mm)) '%%.\n'])
fprintf(['Median width inflation was ' num2str(round(100*(median(MPwidths ./ BayesWidths)-1))) ' +/- ' ...
    num2str(1/(2*ksdensity(100*MPwidths ./ BayesWidths - 1, median(100*MPwidths./BayesWidths - 1))*sqrt(mm))) '%%.\n'])
fprintf(['Avg rel SG width was ' num2str(mean(SGwidths ./ true_sigmas2)) ' +/- ' ...
    num2str(std(SGwidths ./ true_sigmas2)/sqrt(mm)) ' with coverage ' num2str(mean(SGcoverage)) ...
    ' +/- ' num2str(sqrt(alpha*(1-alpha)/mm)) '.\n'])
fprintf(['Median rel SG width was ' num2str(median(SGwidths ./ true_sigmas2)) ' +/- ' ...
    num2str(1/(2*ksdensity(SGwidths ./ true_sigmas2, median(SGwidths./true_sigmas2))*sqrt(mm))) ' with coverage ' num2str(mean(SGcoverage)) ...
    ' +/- ' num2str(sqrt(alpha*(1-alpha)/mm)) '.\n'])
fprintf(['Avg rel SG Bayes width was ' num2str(mean(BayesWidthsSG ./ true_sigmas2)) ' +/- ' ...
    num2str(std(BayesWidthsSG ./ true_sigmas2)/sqrt(mm)) ' with coverage ' num2str(mean(BayesCoverageSG)) ...
    ' +/- ' num2str(sqrt(alpha*(1-alpha)/mm)) '.\n'])
fprintf(['Avg SG width inflation was ' num2str(round(100*(mean(SGwidths ./ BayesWidthsSG)-1))) ...
    '%% +/- ' num2str(100*std(SGwidths ./ BayesWidthsSG)/sqrt(mm)) '%%.\n'])
fprintf(['Median SG width inflation was ' num2str(round(100*(median(SGwidths ./ BayesWidthsSG)-1))) ' +/- ' ...
    num2str(1/(2*ksdensity(100*SGwidths ./ BayesWidthsSG - 1, median(100*SGwidths./BayesWidthsSG - 1))*sqrt(mm))) '%%.\n'])

% Save output
filename = ['MPSGBayes' num2str(run) '_n-' num2str(n) '_p-' num2str(p) '_shape-' num2str(shape_sigma2) ...
    '_scaleInv-' num2str(1/scale_sigma2) '_lambda-' num2str(lambda_M) '.mat'];
save(filename, 'true_sigmas2', 'theta2', 'MPbounds', 'SGbounds', 'BayesBounds', ...
    'BayesBoundsSG', 'DTHbounds', 'DSGbounds', ...
    'MPknSGbounds', 'bayesian_th', 'bayesian_sg', 'subruntime', 'seed');