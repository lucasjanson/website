p = list()
# fill list with parameters to vary over
p$alpha = 0.05
p$mm = 500
p$p = 1000
p$n.over.p = 0.5
p$mag = 1
p$spar = c(.001, .005, 0.01, .05, 0.1)
p$sig = 1
repeats = 20

# compute some statistics
length(p)
len = rep(NA, length(p))
for(i in 1:length(p)) len[i] = length(p[[i]])
n = prod(len)

# populate list with all combinations
for(i in 1:(length(p)-1)){
	for(j in names(p)[1:i]){
		p[[j]] = rep(p[[j]], len[i+1])
	}
	for(j in names(p)[(i+1):length(names(p))]){
		p[[j]] = rep(p[[j]], each = len[i])
	}
}
params = data.frame(p)

# get rid of extraneous rows of params
good_rows = 1:nrow(params)
for(i in 1:nrow(params)){
	conds = c(floor(params$spar[i]*params$p[i]) == 0)
	if(any(conds)){good_rows = good_rows[good_rows != i]}
}
for(i in 1:length(p)){
	p[[i]] = p[[i]][good_rows]
}

# convert list to data frame and save
params = as.matrix(data.frame(p))
params.tmp = params
if(repeats>1){for(i in 2:repeats){params = rbind(params, params.tmp)}}
params = data.frame(params)
save('params', file = 'params_sigma2.rdata')


