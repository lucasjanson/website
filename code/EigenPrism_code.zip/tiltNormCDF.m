function F = tiltNormCDF(x, mean, var)

c = 1/(var*exp(-mean^2/(2*var)) + sqrt(2*pi*var)*mean*(1 - normcdf(-mean/sqrt(var))));
F = c*(var*(exp(-mean^2/(2*var)) - exp(-x.^2./(2*var))) + sqrt(2*pi*var)*mean*(normcdf(x/sqrt(var)) - normcdf(-mean/sqrt(var))));
end