function x = tiltNormCDFinv(F, mean, var, tol)

x0 = -mean;
x1 = mean + var;
Fx1 = tiltNormCDF(x1, mean, var);
while Fx1 < F
    x1 = 2*x1;
    Fx1 = tiltNormCDF(x1, mean, var);
end
x = x1;
Fx = Fx1;
while abs(F - Fx) > tol
    x = (x0 + x1)/2;
    Fx = tiltNormCDF(x, mean, var);
    if Fx > F, x1 = x; end
    if Fx < F, x0 = x; end
end

end