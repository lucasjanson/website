% Before running script, define 'run' variable as row of parameter matrix
% to use and 'version_num' variable as identifier of parameter matrix (see
% makeParams.m)

% Load CVX
cd cvx %this folder should be wherever cvx is stored
cvx_setup;
cd ..

% Load parameters of simulation
load(['paramsEP' num2str(version_num) '.mat'])
dir = ['../results/EP' num2str(params.version) '/'];
names = fieldnames(params);
for i = 1:numel(names)
    assignin('caller',names{i},params.(names{i}));
end

n = ns; %number of observations
rhos = 10.^invlogit10rho./(1+10.^invlogit10rho); %see paper for definition of rho
nnz = p-round((1-sparsity)*p); %number of nonzero entries in coefficient vector

% Initialize variables to store results
MPbounds = nan(nBeta, length(rhos), Xper, 2);
MP2bounds = nan(nBeta, length(rhos), Xper, 2);
Hbounds = nan(nBeta, length(rhos), Xper, 2);
SGbounds = nan(nBeta, length(rhos), Xper, 2);
DTHbounds = nan(nBeta, length(rhos), Xper, 2);
DSGbounds = nan(nBeta, length(rhos), Xper, 2);

% Set random seed for coefficients
RandStream.setGlobalStream(RandStream('mt19937ar','seed', 1000*params.version));
seed0 = RandStream.getGlobalStream.Seed;

% Draw random coefficient vectors
thetas = zeros(p,nBeta); 
for i = 1:nBeta
    thetas(randperm(p,nnz),i) = normrnd(0,1,nnz,1);
end

% Set random seed for simulated data
RandStream.setGlobalStream(RandStream('mt19937ar','seed', sum(1000*clock)*run));
seed = RandStream.getGlobalStream.Seed;

tic

for j = 1:Xper
    clear X U D d lambda w w_th w_sg y
    
    % Generate design matrix
    Xok = false;
    while ~Xok
        switch design
            case 1
                X = normrnd(0, 1, n, p);
            case 2
                X = trnd(3, n, p) / sqrt(3);
            case 3
                X = (exprnd(1, n, p) - 1);
            case 4
                prob = .01;
                X = (binornd(1, prob, n, p) - prob) / sqrt(prob*(1-prob));
            case 5
                prob = .1;
                X = (binornd(1, prob, n, p) - prob) / sqrt(prob*(1-prob));
            case 6
                prob = .5;
                X = (binornd(1, prob, n, p) - prob) / sqrt(prob*(1-prob));
            case 7
                prob = .001;
                X = (binornd(1, prob, n, p) - prob) / sqrt(prob*(1-prob));
            case 8
                prob = .0001;
                X = (binornd(1, prob, n, p) - prob) / sqrt(prob*(1-prob));
            case 9 % random-ish off-diagonal covariances
                corr = 0.5;
                Sig = eye(p); Sig(1:2:end) = corr; Sig(2:2:end) = -corr; Sig = Sig+(1-corr)*eye(p);
                Sig = nearestSPD(Sig);
                Sig = Sig+diag(1-diag(Sig));
                X = mvnrnd(zeros(1,p),Sig,n);
            case 10 % random-ish off-diagonal covariances
                corr = 0.1;
                Sig = eye(p); Sig(1:2:end) = corr; Sig(2:2:end) = -corr; Sig = Sig+(1-corr)*eye(p);
                Sig = nearestSPD(Sig);
                Sig = Sig+diag(1-diag(Sig));
                X = mvnrnd(zeros(1,p),Sig,n);
            case 11
                corr = 0.1;
                Sig = (1-corr)*eye(p) + corr*ones(p,p);
                X = mvnrnd(zeros(1,p),Sig,n);
            case 12
                X = trnd(5, n, p) / sqrt(5/3);
        end
        [U,D,~] = svd(X*X');
        d = sqrt(diag(D));
        
        % Find w for EigenPrism (for theta)
        lambda = d.^2/p;
        cvx_begin quiet
        variable t
        variable w(n)
        minimize t
        subject to
            sum(w) == 0;
            sum(w .* lambda) == 1;
            norm([w; (t/2-1)/2])  <= (t/2+1)/2;
            norm([w .* lambda; (t/2-1)/2]) <= (t/2+1)/2;
        cvx_end
        
        w_th = w;
        var_th = t;
        
        if ~strcmp(cvx_status, 'Failed'), Xok = true; end
        
        % Find w for EigenPrism (for sigma)
        cvx_begin quiet
        variable t
        variable w(n)
        minimize t
        subject to
            sum(w) == 1;
            sum(w .* lambda) == 0;
            norm([w; (t/2-1)/2])  <= (t/2+1)/2;
            norm([w .* lambda; (t/2-1)/2]) <= (t/2+1)/2;
        cvx_end
        
        w_sg = w;
        var_sg = t;
        
        if ~strcmp(cvx_status, 'Failed')
            Xok = true; 
        else
            fprintf('Design Matrix No Good\n')
        end
    end
    
    % Compute EigenPrism quantities for all coefficient and rho values
    for i = 1:nBeta
        th = thetas(:,i);
        for k = 1:length(rhos)
            rho = rhos(k);
            theta2 = total*rho;
            theta = sqrt(theta2)*th./norm(th,2);
            sigma2 = total*(1-rho);
                
            y = X*theta + sqrt(sigma2)*normrnd(0, 1, n, 1);
            
            % EigenPrism estimates
            th_hat = sum(w_th .* (U'*y).^2);
            sg_hat = sum(w_sg .* (U'*y).^2);
            tot_hat = sum(y.^2)/n;
            
            % Dicker (2014) estimates
            Xty_norm = sum((X'*y).^2); y_norm = sum(y.^2);
            dth_hat = (Xty_norm - p*y_norm)/(n*(n+1));
            dsg_hat = ((p+n+1)*y_norm - Xty_norm)/(n*(n+1));
            
            % Compute CIs
            MPbounds(i,k,j,:) = th_hat + tot_hat * sqrt(var_th)*[norminv(alpha/2) norminv(1-alpha/2)];
            MP2bounds(i,k,j,:) = MP2stepCI2(th_hat,tot_hat,d,p,U,y,alpha);
            SGbounds(i,k,j,:) = sg_hat + tot_hat * sqrt(var_sg)*[norminv(alpha/2) norminv(1-alpha/2)];
            Hbounds(i,k,j,:) = MPbounds(i,k,j,:)/tot_hat; %signal-to-noise ratio (or heritability) CI
            % See Corollary 1 of Dicker (2014)
            DTHbounds(i,k,j,:) = dth_hat + sqrt(2*((p/n)*(dth_hat+dsg_hat)^2 + dsg_hat^2 + dth_hat^2)/n)*[norminv(alpha/2) norminv(1-alpha/2)];
            DSGbounds(i,k,j,:) = dsg_hat + sqrt(2*((1+p/n)*(dsg_hat+dth_hat)^2 - dsg_hat^2 + 3*dth_hat^2)/n)*[norminv(alpha/2) norminv(1-alpha/2)];
        end
    end
    
    subruntime = toc;
    if mod(j,1) == 0, fprintf(['Simulation ' num2str(j) ' Complete, runtime = ' num2str(subruntime) '\n']), end
end

% Clip CIs at 0
MPbounds(:,:,:,1) = max(MPbounds(:,:,:,1),0);
MPbounds(:,:,:,2) = max(MPbounds(:,:,:,2),0);
MP2bounds(:,:,:,1) = max(MP2bounds(:,:,:,1),0);
MP2bounds(:,:,:,2) = max(MP2bounds(:,:,:,2),0);
SGbounds(:,:,:,1) = max(SGbounds(:,:,:,1),0);
SGbounds(:,:,:,2) = max(SGbounds(:,:,:,2),0);
Hbounds(:,:,:,1) = max(Hbounds(:,:,:,1),0);
Hbounds(:,:,:,1) = min(Hbounds(:,:,:,1),1);
Hbounds(:,:,:,2) = max(Hbounds(:,:,:,2),0);
Hbounds(:,:,:,2) = min(Hbounds(:,:,:,2),1);
DTHbounds(:,:,:,1) = max(DTHbounds(:,:,:,1),0);
DTHbounds(:,:,:,2) = max(DTHbounds(:,:,:,2),0);
DSGbounds(:,:,:,1) = max(DSGbounds(:,:,:,1),0);
DSGbounds(:,:,:,2) = max(DSGbounds(:,:,:,2),0);

% Save output
if ~exist(dir, 'dir'), mkdir(dir); end
filename = [dir 'EP' ...
    num2str(run) '_n-' num2str(n) '_p-' num2str(p) '_total-' num2str(total) ...
    '_maxAbsInvLogit10rho-' num2str(max(invlogit10rho)) '.mat'];
save(filename, 'MPbounds', 'MP2bounds', 'Hbounds', 'SGbounds', ...
    'DTHbounds', 'DSGbounds', 'subruntime', 'seed', 'seed0');